import pyttsx3

class TextSpeaker:
    def __init__(self, rate=150, volume=1):
        # 初始化 TTS 引擎
        self.engine = pyttsx3.init()

        # 设置语音属性
        self.engine.setProperty('rate', rate)  # 语速
        self.engine.setProperty('volume', volume)  # 音量（0.0 到 1.0）

    def speak(self, text):
        """将文本转换为语音并播放"""
        self.engine.say(text)
        self.engine.runAndWait()  # 等待语音播放完成

    def close(self):
        """关闭引擎"""
        self.engine.stop()


if __name__ == '__main__':
    # 创建 TTS 对象
    tts = TextSpeaker(rate=150, volume=1)

    # 输入文本
    text = [
        "商品已经抢到了，请抓紧时间付款！！",
        "我丶：送出了 × 1"
    ]

    # 循环播放文本
    for t in text:
        tts.speak(t)

    # 完成后关闭引擎
    tts.close()
