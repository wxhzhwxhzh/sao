  
#!/usr/bin/env python
# -*- coding:utf-8 -*-
#-导入库
from DrissionPage import Chromium,ChromiumOptions
from AlarmClock import AlarmClock
from TextSpeaker import TextSpeaker

时=19
分=40
秒=0

speaker=TextSpeaker()
co=ChromiumOptions()
browser= Chromium()
tab1=browser.new_tab()



def saoma(i:int):
    tab1.get('https://passport.jd.com/new/login.aspx?ReturnUrl=https%3A%2F%2Fwww.jd.com%2F')
    info="程序暂停中，请扫码登录....."
    print(info)
    speaker.speak(info)
    tab1.wait(2)
    speaker.speak(f"扫码倒计时{i}秒")
    list=[k  for k in range(i)]
    list.reverse()
    for j in list:
        speaker.speak(str(j)+"秒")
        tab1.wait(1)
        




def jiesuan():
    print("点击结算..")
    tab1.ele("t:a@@text()=去结算").click()
    speaker.speak(f'商品已经下单成功，请及时付款')
   


saoma(10)
clock=AlarmClock()
clock.add_task(jiesuan, hour=时, minute=分, second=秒)
tab1.get('https://cart.jd.com/cart_index')
info2=f"闹钟开始运行，将在{时}时{分}分{秒}秒执行任务，点击结算按钮，期间请不要关闭浏览器"
print(info2)
speaker.speak(info2)
clock.start()