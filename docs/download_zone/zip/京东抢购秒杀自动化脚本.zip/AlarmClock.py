#!/usr/bin/env python
# -*- coding:utf-8 -*-
#-导入库  pip install apscheduler


from apscheduler.schedulers.blocking import BlockingScheduler
from apscheduler.triggers.cron import CronTrigger


class AlarmClock:
    def __init__(self):
        # 初始化调度器
        self.scheduler = BlockingScheduler()

    def add_task(self, task_func, **cron_args):
        """
        注册一个 Cron 类型的定时任务
        :param task_func: 任务执行的函数
        :param cron_args: CronTrigger 的参数（例如 hour, minute, day_of_week 等）
        """
        trigger = CronTrigger(**cron_args)
        # 将任务添加到调度器
        self.scheduler.add_job(task_func, trigger)

    def start(self):
        """启动调度器"""
        print("定时闹钟正在运行中...")
        self.scheduler.start()

    def stop(self):
        """停止调度器"""
        print("Stopping Alarm Clock...")
        self.scheduler.shutdown()

if __name__ == "__main__":
    import datetime
 
    # 示例任务：打印当前时间
    def print_current_time():
        now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        print(f"Task executed at {now}")

    # 示例任务：打印当天日期
    def print_today_date():
        today = datetime.datetime.today().strftime('%Y-%m-%d')
        print(f"Today's date is: {today}")

    # 创建 AlarmClock 实例
    alarm_clock = AlarmClock()

    # 添加任务：每天中午 12 点打印当天日期
    alarm_clock.add_task(print_today_date, hour=12, minute=0)

    # 添加任务：每周一早上 8 点打印当前时间
    alarm_clock.add_task(print_current_time, day_of_week='mon', hour=8, minute=0)

    # 启动闹钟
    alarm_clock.start()

    # 如果需要停止，可以调用 alarm_clock.stop()
