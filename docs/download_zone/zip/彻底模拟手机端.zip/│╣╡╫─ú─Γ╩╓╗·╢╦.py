#!/usr/bin/env python
# -*- coding:utf-8 -*-
#-导入库
from DrissionPage import Chromium,ChromiumOptions

user_agents = {
    "Chrome_Windows": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36",
    "Firefox_Windows": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:110.0) Gecko/20100101 Firefox/110.0",
    "Safari_macOS": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Version/13.1 Safari/537.36",
    "Edge_Windows": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36 Edge/110.0.1587.57",
    "Chrome_Android": "Mozilla/5.0 (Linux; Android 12; Pixel 5 Build/SP1A.210812.016) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Mobile Safari/537.36",
    "Safari_iOS": "Mozilla/5.0 (iPhone; CPU iPhone OS 15_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.1 Mobile/15E148 Safari/604.1",
    "Opera_Windows": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36 OPR/97.0.4692.71"
}


co=ChromiumOptions()
# 设置ua
co.set_user_agent(user_agents["Chrome_Android"])
tab = Chromium(co).latest_tab

# 设置界面模式
zoom={
  "command": "Emulation.setDeviceMetricsOverride",
  "parameters": {
    "width": 360,                # 设备的宽度（像素）
    "height": 740,               # 设备的高度（像素）
    "deviceScaleFactor": 1,    # 设置设备的缩放比例（相当于调整 DPI）
    "mobile": True,             # 设置是否为手机模拟（通常为 `true` 或 `false`）
    "scale": 1                 # 页面缩放比例（0.8 表示页面缩小到 80%）
  }
}
tab.run_cdp(zoom["command"],**zoom["parameters"])



tab.get("https://www.baidu.com/")

input('继续 ?') 
